package makyee.pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.time.Duration;

public class MakyeePage {

    public final String errorMessageH1 = "//h2[@id='swal2-title']";
    public final String errorMessageH2 = "//div[@id='swal2-html-container']";

    @FindBy(xpath = "//input[@id='searchInputHeader']")
    public WebElement searchInput;

    @FindBy(xpath = "//a[contains(@data-name,'Palm Beach Towers 3')]")
    public WebElement searchResultList;

    @FindBy(xpath = "//span[contains(@class,'search-btn3 d-flex align-items-center')]")
    public WebElement searchButton;

    @FindBy(xpath = "//td[@class='for-desk-mini']/a")
    public WebElement listTableLink;

    @FindBy(xpath = "//div[@class='d-flex w-100']//div[1]//*[name()='svg']")
    public WebElement saveFavoriteButton;

    private WebDriver webDriver;
    private WebDriverWait wait;

    public WebDriver getWebDriver() {
        return webDriver;
    }

    public WebDriverWait getWait() {
        return wait;
    }

    public MakyeePage() {
        webDriver = new ChromeDriver();
        PageFactory.initElements(webDriver, this);
        wait = new WebDriverWait(webDriver, Duration.ofSeconds(5));
        webDriver.manage().window().maximize();
    }

}
