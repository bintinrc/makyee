package makyee.steps;

import io.cucumber.java.After;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import makyee.pages.MakyeePage;
import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;

import java.util.Map;

public class MakyeeSteps {

    private MakyeePage page = new MakyeePage();

    @Given("User opens page url {string}")
    public void selectFilters(String url) {
        page.getWebDriver().get(url);
    }

    @When("User fills in search data {string} in search input")
    public void fillInSearchInput(String data) {
        page.searchInput.click();
        page.searchInput.sendKeys(data);
    }

    @And("User clicks search button")
    public void clickSearchButton() {
        page.searchResultList.click();
        page.searchButton.click();
    }

    @And("User select property from search result list")
    public void clickSearchResultList() {
        page.getWait().until(ExpectedConditions.elementToBeClickable(page.listTableLink)).click();
    }

    @And("User save property as favorite")
    public void saveToFavorites() {
        page.saveFavoriteButton.click();
    }

    @Then("User verifies alert is displayed with correct error message")
    public void verifyAlertMessages(Map<String, String> messages) {
        String top = page.getWait().until(ExpectedConditions.presenceOfElementLocated(By.xpath(page.errorMessageH1))).getText();
        String bottom = page.getWait().until(ExpectedConditions.presenceOfElementLocated(By.xpath(page.errorMessageH2))).getText();
        Assert.assertEquals("incorrect top alert message:", messages.get("top"), top);
        Assert.assertEquals("incorrect bottom alert message:", messages.get("bottom"), bottom);
    }

    @After
    public void closeBrowser() {
        page.getWebDriver().quit();
    }

}
