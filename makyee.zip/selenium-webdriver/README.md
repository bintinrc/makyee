1. This project is java based using cucumber framework and maven for all dependencies
2. To run the test cases, you need to first pre-installed java & chrome browser
3. To run the test case, go to /src/test/java/test_run/TestRun.java and run this class
4. You can view the report after test case run completed
5. To evaluate the structure of the script, you can start from /src/test/resources/makyee_properties.feature